# Powershell-Calculator

Honestly, I started learning powershel today
