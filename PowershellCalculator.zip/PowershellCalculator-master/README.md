# PowershellCalculator
Simple Calculator made in Powershell
